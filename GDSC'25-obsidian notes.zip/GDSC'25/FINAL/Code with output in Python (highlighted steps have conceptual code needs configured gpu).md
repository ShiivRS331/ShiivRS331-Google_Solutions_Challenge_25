**Step 1: Audio Preprocessing (STFT and CQT)**

**Methodology:**

1. **Load Audio Data:** Use a library like `librosa` to load your audio file.
2. **Short-Time Fourier Transform (STFT):**
    - Apply the STFT to the audio signal to obtain a spectrogram.
    - The spectrogram represents the signal's frequency content over time.
3. **Constant-Q Transform (CQT):**
    - Apply the CQT to the audio signal to obtain a CQT representation.
    - The CQT provides a logarithmic frequency resolution, which is more musically relevant.

**Python Code (Using librosa):** 
1_audio_processing.py
$$
import librosa  
import librosa.display  
import matplotlib.pyplot as plt  
import numpy as np  
  
def audio_preprocessing(audio_file):  
    """  
    Performs audio preprocessing using STFT and CQT.  
    Args:        audio_file (str): Path to the audio file.  
    Returns:        tuple: (spectrogram, cqt_representation, sample_rate)    """  
    # 1. Load Audio Data  
    y, sr = librosa.load(audio_file)  
  
    # 2. STFT  
    stft = librosa.stft(y)  
    spectrogram = np.abs(stft)  # Magnitude spectrogram  
  
    # 3. CQT    cqt = librosa.cqt(y, sr=sr)  
    cqt_representation = np.abs(cqt)  
  
    return spectrogram, cqt_representation, sr  
  
# Example usage  
audio_file = "C:\\Users\\rsshi\OneDrive\Desktop\GDSC'25\kal.wav" # Replace with your audio file  
spectrogram, cqt_representation, sample_rate = audio_preprocessing(audio_file)  
  
# Visualization (Optional)  
plt.figure(figsize=(12, 6))  
  
plt.subplot(1, 2, 1)  
librosa.display.specshow(librosa.amplitude_to_db(spectrogram, ref=np.max), sr=sample_rate, x_axis='time', y_axis='log')  
plt.title('Spectrogram')  
  
plt.subplot(1, 2, 2)  
librosa.display.specshow(librosa.amplitude_to_db(cqt_representation, ref=np.max), sr=sample_rate, x_axis='time', y_axis='cqt_note')  
plt.title('CQT Representation')  
  
plt.tight_layout()  
plt.show()  
  
print("Audio Preprocessing Done")
$$
OUTPUT:
![[op1.png]]
___

==**Step 2: Note, Octave, and Frequency Detection**==.  - ===GPU===

**Methodology:**

1. **CNN Model:**
    - Design a Convolutional Neural Network (CNN) to analyze the spectrogram or CQT representation.
    - The CNN should be trained to predict the note, octave, and frequency at each time frame.
2. **Microtone Detection (Advanced):**
    - For microtones, you'll likely need a separate, specialized CNN model or a fine-tuned version of the note detection CNN.
    - This model will need a very high frequency resolution, and labeled data that includes microtonal variations.
3. **Training Data:**
    - Create a dataset of audio clips with corresponding labels for notes, octaves, frequencies, and (if applicable) microtones.
4. **Model Training:**
    - Train the CNN models using your dataset.

**Python Code (Conceptual - TensorFlow/Keras):**
2_note_octave_freq_detection.py
$$
import tensorflow as tf  
from tensorflow import keras  
from tensorflow.keras import layers  
import librosa  
import numpy as np  
import os  
import random  
  
# GPU verification and memory management  
gpus = tf.config.list_physical_devices('GPU')  
if gpus:  
    try:  
        for gpu in gpus:  
            tf.config.experimental.set_memory_growth(gpu, True)  
        logical_gpus = tf.config.list_logical_devices('GPU')  
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")  
    except RuntimeError as e:  
        print(e)  
else:  
    print("No GPU detected, using CPU.")  
  
def audio_preprocessing(audio_file):  
    y, sr = librosa.load(audio_file)  
    stft = librosa.stft(y)  
    spectrogram = np.abs(stft)  
    return spectrogram, sr  
  
def create_note_detection_model(input_shape, num_notes, num_octaves):  
    model = keras.Sequential([  
        layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),  
        layers.MaxPooling2D((2, 2)),  
        layers.Conv2D(64, (3, 3), activation='relu'),  
        layers.MaxPooling2D((2, 2)),  
        layers.Flatten(),  
        layers.Dense(128, activation='relu'),  
        layers.Dense(num_notes, activation='softmax', name='note_output'),  
        layers.Dense(num_octaves, activation='softmax', name='octave_output'),  
        layers.Dense(1, name='frequency_output')  
    ])  
    model.compile(optimizer='adam',  
                  loss={'note_output': 'categorical_crossentropy',  
                        'octave_output': 'categorical_crossentropy',  
                        'frequency_output': 'mse'},  
                  metrics={'note_output': 'accuracy',  
                           'octave_output': 'accuracy',  
                           'frequency_output': 'mae'})  
    return model  
  
def generate_random_dataset(num_samples, num_notes, num_octaves, sample_rate=44100, duration=1.0):  
    """Generates a random dataset for testing."""  
    audio_files = []  
    note_labels = []  
    octave_labels = []  
    frequency_labels = []  
  
    for _ in range(num_samples):  
        # Create a simple sine wave audio file  
        freq = random.uniform(100, 1000)  # Random frequency  
        t = np.linspace(0, duration, int(sample_rate * duration), False)  
        audio = np.sin(2 * np.pi * freq * t)  
        audio_file = f"temp_audio_{random.randint(1000, 9999)}.wav"  
        librosa.output.write_wav(audio_file, audio, sample_rate)  
        audio_files.append(audio_file)  
  
        # Random labels  
        note_label = random.randint(0, num_notes - 1)  
        octave_label = random.randint(0, num_octaves - 1)  
        frequency_label = freq  
  
        note_labels.append(note_label)  
        octave_labels.append(octave_label)  
        frequency_labels.append(frequency_label)  
  
    return audio_files, note_labels, octave_labels, frequency_labels  
  
def prepare_batch_data(audio_files, note_labels, octave_labels, frequency_labels, num_notes, num_octaves):  
    spectrograms = []  
    note_one_hots = []  
    octave_one_hots = []  
    frequency_labels_list = []  
  
    for audio_file, note_label, octave_label, frequency_label in zip(audio_files, note_labels, octave_labels, frequency_labels):  
        spectrogram, _ = audio_preprocessing(audio_file)  
        spectrogram = np.expand_dims(spectrogram, axis=-1)  
        spectrograms.append(spectrogram)  
  
        note_one_hot = np.zeros(num_notes)  
        note_one_hot[note_label] = 1  
        note_one_hots.append(note_one_hot)  
  
        octave_one_hot = np.zeros(num_octaves)  
        octave_one_hot[octave_label] = 1  
        octave_one_hots.append(octave_one_hot)  
  
        frequency_labels_list.append(frequency_label)  
  
    return np.array(spectrograms), np.array(note_one_hots), np.array(octave_one_hots), np.array(frequency_labels_list)  
  
# Example Usage  
num_notes = 12  
num_octaves = 5  
num_samples = 100  
batch_size = 32  
epochs = 20  
  
# Generate Random Dataset  
audio_files, note_labels, octave_labels, frequency_labels = generate_random_dataset(num_samples, num_notes, num_octaves)  
  
# Prepare Data  
spectrograms, note_one_hots, octave_one_hots, frequency_labels_array = prepare_batch_data(audio_files, note_labels, octave_labels, frequency_labels, num_notes, num_octaves)  
  
input_shape = spectrograms.shape[1:]  
  
# Create Model  
model = create_note_detection_model(input_shape, num_notes, num_octaves)  
  
# Training Loop  
model.fit(spectrograms, {'note_output': note_one_hots, 'octave_output': octave_one_hots, 'frequency_output': frequency_labels_array}, epochs=epochs, validation_split=0.2, batch_size=batch_size)  
  
# Evaluation  
loss, note_loss, octave_loss, frequency_loss, note_accuracy, octave_accuracy, frequency_mae = model.evaluate(spectrograms, {'note_output': note_one_hots, 'octave_output': octave_one_hots, 'frequency_output': frequency_labels_array})  
print(f"Note Accuracy: {note_accuracy}, Octave Accuracy: {octave_accuracy}, Frequency MAE: {frequency_mae}")  
  
# Prediction  
predictions = model.predict(spectrograms[:5])  
print("Predictions:", predictions)  
  
# Clean up temp files  
for file in audio_files:  
    os.remove(file)
$$
OUTPUT:
cuda with cuDNN 

___

===**Step 3: Raga and Tala Recognition**===. - ===GPU===

**Methodology:**

1. **Transformer Model:**
    - Design a Transformer model to analyze the sequence of detected notes.
    - The Transformer should be trained to predict the raga and tala at each time frame or for a segment of the music.
2. **Sequence Representation:**
    - Convert the detected notes into a sequence representation that the Transformer can process.
    - This could involve representing notes as indices or one-hot vectors.
3. **Training Data:**
    - Create a dataset of audio clips (or note sequences) with corresponding labels for ragas and talas.
4. **Model Training:**
    - Train the Transformer model using your dataset.

**Python Code (Conceptual - TensorFlow/Keras):**
3_raga_tala_recognition.py
$$
import tensorflow as tf  
from tensorflow.keras import layers  
import numpy as np  
import random  
  
# GPU verification and memory management  
gpus = tf.config.list_physical_devices('GPU')  
if gpus:  
    try:  
        for gpu in gpus:  
            tf.config.experimental.set_memory_growth(gpu, True)  
        logical_gpus = tf.config.list_logical_devices('GPU')  
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")  
    except RuntimeError as e:  
        print(e)  
else:  
    print("No GPU detected, using CPU.")  
  
def create_raga_tala_model(sequence_length, num_notes, num_ragas, num_talas):  
    inputs = layers.Input(shape=(sequence_length, num_notes))  
    x = layers.MultiHeadAttention(num_heads=8, key_dim=64)(inputs, inputs)  
    x = layers.LayerNormalization(epsilon=1e-6)(x + inputs)  
    x = layers.Dense(256, activation='relu')(x)  
    x = layers.GlobalAveragePooling1D()(x)  
    raga_output = layers.Dense(num_ragas, activation='softmax', name='raga_output')(x)  
    tala_output = layers.Dense(num_talas, activation='softmax', name='tala_output')(x)  
    model = tf.keras.Model(inputs=inputs, outputs=[raga_output, tala_output])  
    model.compile(optimizer='adam',  
                  loss={'raga_output': 'categorical_crossentropy',  
                        'tala_output': 'categorical_crossentropy'},  
                  metrics={'raga_output': 'accuracy',  
                           'tala_output': 'accuracy'})  
    return model  
  
def generate_random_dataset(num_samples, sequence_length, num_notes, num_ragas, num_talas):  
    """Generates a random dataset for testing."""  
    note_sequences = []  
    raga_labels = []  
    tala_labels = []  
  
    for _ in range(num_samples):  
        note_sequence = [random.randint(0, num_notes - 1) for _ in range(sequence_length)]  
        raga_label = random.randint(0, num_ragas - 1)  
        tala_label = random.randint(0, num_talas - 1)  
        note_sequences.append(note_sequence)  
        raga_labels.append(raga_label)  
        tala_labels.append(tala_label)  
  
    return note_sequences, raga_labels, tala_labels  
  
def prepare_sequence_data(note_sequences, raga_labels, tala_labels, num_notes, num_ragas, num_talas):  
    """Prepares batch data for training."""  
    sequences_one_hot = []  
    raga_one_hots = []  
    tala_one_hots = []  
  
    for note_sequence, raga_label, tala_label in zip(note_sequences, raga_labels, tala_labels):  
        sequence_length = len(note_sequence)  
        note_sequence_one_hot = np.zeros((sequence_length, num_notes))  
        for i, note_index in enumerate(note_sequence):  
            note_sequence_one_hot[i, note_index] = 1  
        raga_one_hot = np.zeros(num_ragas)  
        raga_one_hot[raga_label] = 1  
        tala_one_hot = np.zeros(num_talas)  
        tala_one_hot[tala_label] = 1  
  
        sequences_one_hot.append(note_sequence_one_hot)  
        raga_one_hots.append(raga_one_hot)  
        tala_one_hots.append(tala_one_hot)  
  
    return np.array(sequences_one_hot), np.array(raga_one_hots), np.array(tala_one_hots)  
  
# Example Usage  
num_notes = 12  
num_ragas = 10  
num_talas = 5  
sequence_length = 10 #Example sequence length.  
num_samples = 1000 #number of training examples.  
  
# Generate Random Dataset  
note_sequences, raga_labels, tala_labels = generate_random_dataset(num_samples, sequence_length, num_notes, num_ragas, num_talas)  
  
# Prepare Data  
sequences_one_hot, raga_one_hots, tala_one_hots = prepare_sequence_data(note_sequences, raga_labels, tala_labels, num_notes, num_ragas, num_talas)  
  
# Create Model  
model = create_raga_tala_model(sequence_length, num_notes, num_ragas, num_talas)  
  
# Training Loop  
model.fit(sequences_one_hot, {'raga_output': raga_one_hots, 'tala_output': tala_one_hots}, epochs=20, validation_split=0.2, batch_size=32)  
  
# Evaluation  
loss, raga_loss, tala_loss, raga_accuracy, tala_accuracy = model.evaluate(sequences_one_hot, {'raga_output': raga_one_hots, 'tala_output': tala_one_hots})  
print(f"Raga Accuracy: {raga_accuracy}, Tala Accuracy: {tala_accuracy}")  
  
# Prediction  
predictions = model.predict(sequences_one_hot[:5])  # Predict on the first 5 samples  
print("Predictions (Raga, Tala):", predictions)  
  
#example of how to access the raga and tala prediction separately.  
raga_predictions = predictions[0] #ragas  
tala_predictions = predictions[1] #talas  
  
print("Raga Predictions:", raga_predictions)  
print("Tala Predictions:", tala_predictions)
$$
OUTPUT:
cuda cuDNN


___

**Step 4: Real-Time Visualization**.

**Methodology:**

1. **Integrate with Audio Analysis:**
    - Combine the note, octave, and frequency detection (from Step 2) with the visualization code.
2. **Real-Time Plotting:**
    - Use a plotting library like `matplotlib` or `plotly` to create a real-time graph.
    - Update the graph with the detected notes, octaves, and frequencies as they are received from the audio analysis.
3. **Tala Visualization (Optional):**
    - If you've implemented tala recognition, create a separate visualization for the tala.
    - This could involve displaying the rhythmic cycles, beat patterns, or a visual representation of the tala's structure.
4. **Interactive Elements (Optional):**
    - Add interactive elements to the visualization, such as zoom, pan, or the ability to adjust the time scale.

**Python Code (Integration and Visualization):**
4_real_time_viz.py
$$
import numpy as np  
import sounddevice as sd  
import scipy.signal as signal  
import tkinter as tk  
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  
from matplotlib.figure import Figure  
import threading  
import time  
  
# --- (Note: Assume the CNN note detection model is integrated here) ---  
  
# Define Indian musical notes and their frequencies (octaves 2-6)  
NOTES = {  
    "2": {  
        "S": 65.41, "r1": 69.30, "r2": 73.42, "g1": 77.78, "g2": 82.41,  
        "m1": 87.31, "m2": 92.50, "P": 98.00, "d1": 103.83, "d2": 110.00,  
        "n1": 116.54, "n2": 123.47, "S'": 130.81  
    },  
    "3": {  
        "S": 130.81, "r1": 138.59, "r2": 146.83, "g1": 155.56, "g2": 164.81,  
        "m1": 174.61, "m2": 185.00, "P": 196.00, "d1": 207.65, "d2": 220.00,  
        "n1": 233.08, "n2": 246.94, "S'": 261.63  
    },  
    "4": {  
        "S": 261.63, "r1": 277.18, "r2": 293.66, "g1": 311.13, "g2": 329.63,  
        "m1": 349.23, "m2": 369.99, "P": 392.00, "d1": 415.30, "d2": 440.00,  
        "n1": 466.16, "n2": 493.88, "S'": 523.25  
    },  
    "5": {  
        "S": 523.25, "r1": 554.37, "r2": 587.33, "g1": 622.25, "g2": 659.25,  
        "m1": 698.46, "m2": 739.99, "P": 783.99, "d1": 830.61, "d2": 880.00,  
        "n1": 932.33, "n2": 987.77, "S'": 1046.50  
    },  
    "6": {  
        "S": 1046.50, "r1": 1108.73, "r2": 1174.66, "g1": 1244.51, "g2": 1318.51,  
        "m1": 1396.91, "m2": 1479.98, "P": 1567.98, "d1": 1661.22, "d2": 1760.00,  
        "n1": 1864.66, "n2": 1975.53, "S'": 2093.00  
    }  
}  
  
OCTAVES = ["2", "3", "4", "5", "6"]  
ALL_NOTES = []  
ALL_FREQS = []  
for octave in OCTAVES:  
    for note_name, freq in NOTES[octave].items():  
        ALL_NOTES.append(f"{note_name} ({octave})")  
        ALL_FREQS.append(freq)  
  
def find_nearest_note(freq):  
    """Find the nearest musical note and octave to a given frequency."""  
    if freq <= 0:  
        return None, None  
  
    min_dist = float('inf')  
    nearest_note = None  
    nearest_octave = None  
  
    for octave, notes in NOTES.items():  
        for note, note_freq in notes.items():  
            dist = abs(freq - note_freq)  
            if dist < min_dist:  
                min_dist = dist  
                nearest_note = note  
                nearest_octave = octave  
    return nearest_note, nearest_octave  
  
def detect_note(audio_data, sample_rate):  
    """Detect the dominant frequency and corresponding note in audio data."""  
    if len(audio_data) == 0:  
        return None, None, None  
  
    frequencies, magnitudes = signal.welch(audio_data, sample_rate, nperseg=2048) # nperseg changed.  
    # noise reduction added.    window_size = 3  
    magnitudes_smooth = np.convolve(magnitudes, np.ones(window_size) / window_size, mode='same')  
    dominant_frequency = frequencies[np.argmax(magnitudes_smooth)]  
  
    note, octave = find_nearest_note(dominant_frequency)  
    return dominant_frequency, note, octave  
  
def audio_callback(indata, frames, time, status):  
    global audio_data  
    if status:  
        print(status)  
    audio_data = indata.flatten()  
  
def update_graph():  
    global audio_data, time_data, note_data, freq_data, octave_data, x_offset  
  
    if len(audio_data) > 0:  
        freq, note, octave = detect_note(audio_data, sample_rate) # Replace with CNN output  
  
        if note:  
            current_time = time.time() - start_time  
            time_data.append(current_time)  
            note_data.append(note)  
            freq_data.append(freq)  
            octave_data.append(octave)  
  
            ax.clear()  
            ax.plot([t - x_offset for t in time_data], [NOTES[o][n] if o and n else 0 for n, o in zip(note_data, octave_data)], marker='o', linestyle='-')  
            ax.set_yticks(ALL_FREQS)  
            ax.set_yticklabels(ALL_NOTES)  
            ax.set_xlabel("Time (s)")  
            ax.set_ylabel("Notes")  
            ax.set_xlim(max(0, current_time - 5), current_time + 1)  
            if octave:  
                y_min = NOTES[octave]["S"] - 50  
                y_max = NOTES[octave]["S'"] + 50  
                ax.set_ylim(y_min, y_max)  
            ax.text(0.05, 0.95, f"Note: {note} ({octave})\nFrequency: {freq:.2f} Hz", transform=ax.transAxes, fontsize=12, verticalalignment='top', horizontalalignment='left', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))  
            canvas.draw()  
            detected_label.config(text=f"Detected Note: {note} ({octave}), Frequency: {freq:.2f} Hz")  
  
    root.after(100, update_graph)  
  
# --- (Rest of your Tkinter and audio stream code) ---  
  
audio_data = np.array([])  
time_data = []  
note_data = []  
freq_data = []  
octave_data = []  
sample_rate = 44100  
start_time = time.time()  
x_offset = 0  
  
root = tk.Tk()  
root.title("Shruti App")  
fig = Figure(figsize=(8, 12))  
ax = fig.add_subplot(111)  
canvas = FigureCanvasTkAgg(fig, master=root)  
canvas.get_tk_widget().pack()  
  
detected_label = tk.Label(root, text="Detected Note: None")  
detected_label.pack()  
  
def start_audio_stream():  
    with sd.InputStream(callback=audio_callback, samplerate=sample_rate):  
        while True:  
            time.sleep(0.1)  
  
audio_thread = threading.Thread(target=start_audio_stream)  
audio_thread.daemon = True  
audio_thread.start()  
  
update_graph()  
  
root.mainloop()  
  
print("Real-Time Visualization Implemented")
$$
OUTPUT: 
![[op4.png]]
___

4.1 Real-Time Vocal Training Visualization with Audio File Comparison**

**Description:**

This step implements a real-time vocal training tool that displays two synchronized plots on the same graph. It allows users to compare their real-time singing with a pre-recorded audio file, enabling them to identify and correct discrepancies in pitch, timing, and note accuracy.

**Methodology:**

1. **Audio File Loading:**
    - The user selects an audio file (e.g., a professional singer's performance) using a file dialog.
    - The audio file is loaded and processed using `librosa` and a note detection algorithm (either a custom function or a pre-trained CNN model).
    - The detected notes, frequencies, and timestamps are stored.
2. **Real-Time Audio Capture:**
    - The laptop's microphone captures the user's real-time singing.
    - The captured audio is processed using the same note detection algorithm.
    - The detected notes, frequencies, and timestamps are stored.
3. **Synchronized Plotting:**
    - Two plots are displayed on the same graph:
        - One plot (blue) represents the real-time singing.
        - The other plot (red) represents the uploaded audio file.
    - The time axes of both plots are synchronized, allowing for direct visual comparison.
    - The y-axis displays the frequencies corresponding to Indian musical notes, labeled with the note names and octaves.
4. **Real-Time Update:**
    - The real-time singing plot is updated continuously as the user sings.
    - The uploaded audio file plot remains static, representing the reference performance.
5. **User Interface:**
    - A Tkinter-based GUI provides:
        - A "Load Audio File" button to select the reference audio.
        - A graph displaying the synchronized plots.
**Python Code:**
4_1_real_time_with_audiofile_viz_for_practice.py
$$
import numpy as np  
import sounddevice as sd  
import scipy.signal as signal  
import tkinter as tk  
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  
from matplotlib.figure import Figure  
import threading  
import time  
import librosa  
  
# Define Indian musical notes and their frequencies (octaves 2-6)  
NOTES = {  
    "2": {  
        "S": 65.41, "r1": 69.30, "r2": 73.42, "g1": 77.78, "g2": 82.41,  
        "m1": 87.31, "m2": 92.50, "P": 98.00, "d1": 103.83, "d2": 110.00,  
        "n1": 116.54, "n2": 123.47, "S'": 130.81  
    },  
    "3": {  
        "S": 130.81, "r1": 138.59, "r2": 146.83, "g1": 155.56, "g2": 164.81,  
        "m1": 174.61, "m2": 185.00, "P": 196.00, "d1": 207.65, "d2": 220.00,  
        "n1": 233.08, "n2": 246.94, "S'": 261.63  
    },  
    "4": {  
        "S": 261.63, "r1": 277.18, "r2": 293.66, "g1": 311.13, "g2": 329.63,  
        "m1": 349.23, "m2": 369.99, "P": 392.00, "d1": 415.30, "d2": 440.00,  
        "n1": 466.16, "n2": 493.88, "S'": 523.25  
    },  
    "5": {  
        "S": 523.25, "r1": 554.37, "r2": 587.33, "g1": 622.25, "g2": 659.25,  
        "m1": 698.46, "m2": 739.99, "P": 783.99, "d1": 830.61, "d2": 880.00,  
        "n1": 932.33, "n2": 987.77, "S'": 1046.50  
    },  
    "6": {  
        "S": 1046.50, "r1": 1108.73, "r2": 1174.66, "g1": 1244.51, "g2": 1318.51,  
        "m1": 1396.91, "m2": 1479.98, "P": 1567.98, "d1": 1661.22, "d2": 1760.00,  
        "n1": 1864.66, "n2": 1975.53, "S'": 2093.00  
    }  
}  
  
OCTAVES = ["2", "3", "4", "5", "6"]  
ALL_NOTES = []  
ALL_FREQS = []  
for octave in OCTAVES:  
    for note_name, freq in NOTES[octave].items():  
        ALL_NOTES.append(f"{note_name} ({octave})")  
        ALL_FREQS.append(freq)  
  
def find_nearest_note(freq):  
    """Find the nearest musical note and octave to a given frequency."""  
    if freq <= 0:  
        return None, None  
  
    min_dist = float('inf')  
    nearest_note = None  
    nearest_octave = None  
  
    for octave, notes in NOTES.items():  
        for note, note_freq in notes.items():  
            dist = abs(freq - note_freq)  
            if dist < min_dist:  
                min_dist = dist  
                nearest_note = note  
                nearest_octave = octave  
    return nearest_note, nearest_octave  
  
def detect_note(audio_data, sample_rate):  
    """Detect the dominant frequency and corresponding note in audio data."""  
    if len(audio_data) < 256:  
        return None, None, None  
  
    frequencies, magnitudes = signal.welch(audio_data, sample_rate, nperseg=512)  
    window_size = 3  
    magnitudes_smooth = np.convolve(magnitudes, np.ones(window_size) / window_size, mode='same')  
    dominant_frequency = frequencies[np.argmax(magnitudes_smooth)]  
  
    note, octave = find_nearest_note(dominant_frequency)  
    return dominant_frequency, note, octave  
  
def audio_callback(indata, frames, time, status):  
    global audio_data  
    if status:  
        print(status)  
    audio_data = indata.flatten()  
  
def process_audio_file(audio_file):  
    y, sr = librosa.load(audio_file)  
    time_data_file = []  
    note_data_file = []  
    freq_data_file = []  
    octave_data_file = []  
    time_step = 0.05 # Increased time_step  
    for i in range(0, len(y), int(sr * time_step)):  
        audio_segment = y[i:i + int(sr * time_step)]  
        if len(audio_segment) > int(sr * time_step * .75):  
            freq, note, octave = detect_note(audio_segment, sr)  
            if note:  
                time_data_file.append(i / sr)  
                note_data_file.append(note)  
                freq_data_file.append(freq)  
                octave_data_file.append(octave)  
        else:  
            print(f"Audio segment too short: {len(audio_segment)}") # Added error message  
    return time_data_file, note_data_file, freq_data_file, octave_data_file, sr  
  
def update_graph():  
    global audio_data, time_data, note_data, freq_data, octave_data, x_offset, audio_file_data, start_time, audio_file_sr  
  
    freq, note, octave = None, None, None  
    if len(audio_data) > 0:  
        freq, note, octave = detect_note(audio_data, sample_rate)  
        if note:  
            current_time = time.time() - start_time  
            time_data.append(current_time)  
            note_data.append(note)  
            freq_data.append(freq)  
            octave_data.append(octave)  
  
    fig.clf() # Clear the figure.  
  
    ax1 = fig.add_subplot(211) # real time plot  
    ax2 = fig.add_subplot(212) # audio file plot  
  
    # Plot real-time data    ax1.plot([t - x_offset for t in time_data], [NOTES[o][n] if o and n else 0 for n, o in zip(note_data, octave_data)], marker='o', linestyle='-', color='blue', label='Real-time')  
    ax1.set_yticks(ALL_FREQS)  
    ax1.set_yticklabels(ALL_NOTES)  
    ax1.set_xlabel("Time (s)")  
    ax1.set_ylabel("Notes")  
    ax1.legend()  
    if note and octave:  
        ax1.text(0.05, 0.95, f"Note: {note} ({octave})\nFrequency: {freq:.2f} Hz", transform=ax1.transAxes, fontsize=12, verticalalignment='top', horizontalalignment='left', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))  
        y_min = NOTES[octave]["S"] - 50  
        y_max = NOTES[octave]["S'"] + 50  
        ax1.set_ylim(y_min, y_max)  
  
    # Plot audio file data  
    if audio_file_data:  
        time_data_file, note_data_file_file, freq_data_file_file, octave_data_file_file, audio_file_sr_file = audio_file_data  
  
        print("Audio File Time Data:", time_data_file)  
        print("Audio File Note Data:", note_data_file_file)  
  
        # Filter the time data  
        filtered_time_data_file = []  
        if len(time_data_file) > 0:  
            filtered_time_data_file.append(time_data_file[0])  
            for i in range(1, len(time_data_file)):  
                if time_data_file[i] - time_data_file[i-1] < 10: # Adjust the threshold as needed  
                    filtered_time_data_file.append(time_data_file[i])  
  
        audio_duration = librosa.get_duration(path="C:\\Users\\rsshi\\OneDrive\\Desktop\\GDSC'25\\kal.mp3") # Fixed FutureWarning  
        scaled_time_data_file = []  
        if len(filtered_time_data_file) > 0:  
            audio_time_scale = audio_duration / filtered_time_data_file[-1] if filtered_time_data_file[-1] > 0 else 1  
            scaled_time_data_file = [t * audio_time_scale for t in filtered_time_data_file]  
  
            # Adjust scaled_time_data_file to match real time  
            current_real_time = time.time() - start_time  
            max_audio_time = scaled_time_data_file[-1] if scaled_time_data_file else 0  
  
            if max_audio_time > 0:  
                plot_indices = [i for i, t in enumerate(scaled_time_data_file) if t <= current_real_time]  
                plot_time = [scaled_time_data_file[i] for i in plot_indices]  
                plot_notes = [NOTES[o][n] if o and n else 0 for i, (n, o) in enumerate(zip(note_data_file_file, octave_data_file_file)) if i in plot_indices]  
  
                ax2.plot(plot_time, plot_notes, marker='.', linestyle='-', color='red', label='Audio File')  
                ax2.set_yticks(ALL_FREQS)  
                ax2.set_yticklabels(ALL_NOTES)  
                ax2.set_xlabel("Time (s)")  
                ax2.set_ylabel("Notes")  
                ax2.legend()  
  
                # Dynamic y-axis for audio file plot  
                if plot_indices: # Check if there are any plotted points  
                    # Get the note and octave corresponding to the last plotted time                    last_index = plot_indices[-1]  
                    last_note = note_data_file_file[last_index]  
                    last_octave = octave_data_file_file[last_index]  
                    last_freq = freq_data_file_file[last_index] # Added frequency  
  
                    if last_note and last_octave:  
                        y_min = NOTES[last_octave]["S"] - 50  
                        y_max = NOTES[last_octave]["S'"] + 50  
                        ax2.set_ylim(y_min, y_max)  
                        print(f"Audio File Y-Axis: {y_min}, {y_max}") # Debug print  
                        ax2.text(0.05, 0.95, f"Note: {last_note} ({last_octave})\nFrequency: {last_freq:.2f} Hz", transform=ax2.transAxes, fontsize=12, verticalalignment='top', horizontalalignment='left', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none')) # Added text for audio file  
  
    canvas.draw()  
    root.after(100, update_graph)  
  
# --- (Rest of your Tkinter and audio stream code) ---  
  
audio_data = np.array([])  
time_data = []  
note_data = []  
freq_data = []  
octave_data = []  
sample_rate = 44100  
start_time = time.time()  
x_offset = 0  
audio_file_data = None  
audio_file_sr = None  
  
root = tk.Tk()  
root.title("Vocal Training App")  
fig = Figure(figsize=(12, 12)) # increased figure size  
canvas = FigureCanvasTkAgg(fig, master=root)  
canvas.get_tk_widget().pack()  
  
# Load audio file directly in the code:  
audio_file_path = "C:\\Users\\rsshi\\OneDrive\\Desktop\\GDSC'25\\kal.mp3" # Replace with your file path  
audio_file_data = process_audio_file(audio_file_path)  
  
def start_audio_stream():  
    with sd.InputStream(callback=audio_callback, samplerate=sample_rate):  
        while True:  
            time.sleep(0.1)  
  
audio_thread = threading.Thread(target=start_audio_stream)  
audio_thread.daemon = True  
audio_thread.start()  
  
update_graph()  
  
root.mainloop()  
  
print("Real-Time Vocal Training Visualization Implemented")
$$
OUTPUT:
![[op4.1.png]]

___

===**Step 5: Music Synthesis and Modification**===.  - ===GPU===

**Methodology:**

1. **Input Handling:**
    - Implement functions to load audio files and music sheets (MIDI or MusicXML).
    - Parse music sheets into a symbolic representation (e.g., a list of notes, durations, and other musical parameters).
2. **Prompt Processing:**
    - Develop a system to process user prompts that specify desired modifications.
    - This could involve natural language processing (NLP) techniques to extract musical parameters from the prompt.
3. **Transformer-Based Modification:**
    - Use a Transformer model to encode the input music (audio or symbolic) and the user's prompt.
    - Train the Transformer to generate modified music based on the prompt.
4. **Latent Diffusion Audio Synthesis:**
    - Use a Latent Diffusion Model to generate high-fidelity audio from the Transformer's output or the modified symbolic representation.
5. **Gamaka and Alankar Synthesis (Advanced):**
    - If you're synthesizing gamakas and alankars, you'll need to train your Latent Diffusion Model to generate these specific musical ornaments.
6. **Output Generation:**
    - Generate the modified music as an audio file or music sheet (MIDI or MusicXML), or both.

Python Code (Conceptual - Requires External Libraries and Models):
5_music_synth_modify.py
$$
import tensorflow as tf  
from tensorflow import keras  
from tensorflow.keras import layers  
import librosa  
import music21  
import numpy as np  
import random  
  
# GPU verification and memory management  
gpus = tf.config.list_physical_devices('GPU')  
if gpus:  
    try:  
        for gpu in gpus:  
            tf.config.experimental.set_memory_growth(gpu, True)  
        logical_gpus = tf.config.list_logical_devices('GPU')  
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")  
    except RuntimeError as e:  
        print(e)  
else:  
    print("No GPU detected, using CPU.")  
  
def load_music_input(input_file):  
    if input_file.lower().endswith(('.wav', '.mp3')):  
        audio, sr = librosa.load(input_file)  
        return audio, sr, "audio"  
    elif input_file.lower().endswith(('.mid', '.midi', '.xml', '.musicxml')):  
        score = music21.converter.parse(input_file)  
        music_sequence = music21_to_sequence(score)  
        return music_sequence, None, "symbolic"  
    else:  
        raise ValueError("Unsupported input file format")  
  
def music21_to_sequence(score):  
    """Converts a music21 score to a sequence of musical events."""  
    sequence = []  
    for element in score.recurse():  
        if isinstance(element, music21.note.Note):  
            sequence.append(f"note_{element.nameWithOctave}_{element.duration.quarterLength}")  
        elif isinstance(element, music21.note.Rest):  
            sequence.append(f"rest_{element.duration.quarterLength}")  
        elif isinstance(element, music21.tempo.MetronomeMark):  
            sequence.append(f"tempo_{element.number}")  
        elif isinstance(element, music21.stream.Measure):  
            sequence.append("measure_start")  
    return sequence  
  
def process_prompt(prompt):  
    """Processes a text prompt to extract modification instructions."""  
    prompt = prompt.lower()  
    if "add taan" in prompt:  
        gamaka = "slide" if "slide" in prompt else "default"  
        return {"modification_type": "add_taan", "gamaka": gamaka}  
    else:  
        return {"modification_type": "default", "gamaka": "default"}  
  
def transformer_audio_modification(audio, prompt_data):  
    """Placeholder: Implement Transformer-based audio modification."""  
    # This is a placeholder. A real implementation would involve a trained Transformer model.  
    # For now, we'll add a simple pitch shift as an example.    if prompt_data["modification_type"] == "add_taan":  
        pitch_shift = random.uniform(-2, 2)  # Random pitch shift  
        modified_audio = librosa.effects.pitch_shift(audio, sr=44100, n_steps=pitch_shift)  
        return modified_audio  
    return audio  
  
def transformer_symbolic_modification(music_sequence, prompt_data):  
    """Placeholder: Implement Transformer-based symbolic music modification."""  
    # This is a placeholder. A real implementation would involve a trained Transformer model.  
    modified_sequence = music_sequence.copy()  
    if prompt_data["modification_type"] == "add_taan":  
        # Example: Add a simple taan-like pattern  
        taan_pattern = ["note_C4_0.5", "note_D4_0.5", "note_E4_0.5", "note_F4_0.5"]  
        modified_sequence.extend(taan_pattern)  
    return modified_sequence  
  
def latent_diffusion_audio_generation(music_output):  
    """Placeholder: Implement Latent Diffusion Model for audio generation."""  
    # This is a placeholder. A real implementation would involve a trained Latent Diffusion Model.  
    # For now, we'll return a sine wave as an example.    duration = 5  # seconds  
    sr = 44100  
    t = np.linspace(0, duration, int(sr * duration), False)  
    freq = 440  # Hz  
    audio = np.sin(2 * np.pi * freq * t)  
    return audio  
  
def music_sequence_to_midi(music_output, output_file):  
    """Converts a music sequence to a MIDI file."""  
    score = music21.stream.Stream()  
    offset = 0  
    for event in music_output:  
        if event.startswith("note_"):  
            parts = event.split("_")  
            note_name = parts[1]  
            duration = float(parts[2])  
            note = music21.note.Note(note_name, quarterLength=duration)  
            note.offset = offset  
            score.append(note)  
            offset += duration  
        elif event.startswith("rest_"):  
            duration = float(event.split("_")[1])  
            rest = music21.note.Rest(quarterLength=duration)  
            rest.offset = offset  
            score.append(rest)  
            offset += duration  
        elif event.startswith("tempo_"):  
            tempo = music21.tempo.MetronomeMark(number=float(event.split("_")[1]))  
            score.append(tempo)  
        elif event == "measure_start":  
            pass #measure start is ignored.  
  
    mf = music21.midi.translate.streamToMidiFile(score)  
    mf.open(output_file, 'wb')  
    mf.write()  
    mf.close()  
  
def modify_music(music_input, input_type, prompt_data):  
    if input_type == "audio":  
        modified_music = transformer_audio_modification(music_input, prompt_data)  
        return modified_music, "audio"  
    elif input_type == "symbolic":  
        modified_music = transformer_symbolic_modification(music_input, prompt_data)  
        return modified_music, "symbolic"  
    else:  
        raise ValueError("Invalid input type")  
  
def synthesize_audio(modified_music, modified_type):  
    if modified_type == "audio":  
        return modified_music  
    elif modified_type == "symbolic":  
        return latent_diffusion_audio_generation(modified_music)  
    else:  
        raise ValueError("Invalid modified type")  
  
# Example usage  
try:  
    input_file = "C:\\Users\\rsshi\\OneDrive\\Desktop\\GDSC'25\\kal.mp3" # or "input.mid"  
    music_input, sr, input_type = load_music_input(input_file)  
    prompt = "Add a taan with a slide gamaka"  
    prompt_data = process_prompt(prompt)  
    modified_music, modified_type = modify_music(music_input, input_type, prompt_data)  
    synthesized_audio = synthesize_audio(modified_music, modified_type)  
    output_music(synthesized_audio, "audio", "output.wav", sr)  
    print("Music Synthesis and Modification Implemented")  
except Exception as e:  
    print(f"An error occurred: {e}")
$$
OUTPUT:
need GPU  - cuda with cuDNN 
___

===**Step 6: Gamaka and Alankar Synthesis (Advanced)**===. ===GPU===

**Methodology:**

This step builds upon the music synthesis and modification from Step 5, focusing specifically on generating and manipulating gamakas and alankars.

1. **Gamaka and Alankar Representation:**
    - Define a way to represent gamakas and alankars in your symbolic music representation or as specific audio features.
    - This might involve encoding their characteristic melodic patterns, rhythmic variations, and ornamentation techniques.
2. **Gamaka/Alankar Recognition (Optional):**
    - If you want to automatically identify gamakas and alankars in input audio or music sheets, you'll need a recognition model.
    - This could be a Transformer-based model or a specialized CNN trained on labeled gamaka/alankar data.
3. **Prompt-Based Generation:**
    - Extend your prompt processing system to understand requests for specific gamakas and alankars.
    - This might require more sophisticated NLP or a domain-specific language for describing musical ornaments.
4. **Latent Diffusion Model Fine-Tuning:**
    - Fine-tune your Latent Diffusion Model to generate audio with realistic gamakas and alankars.
    - This might involve training the model on a dataset of audio clips with labeled gamakas and alankars.
5. **Symbolic Generation (Optional):**
    - If you're generating symbolic music, implement logic to add gamaka and alankar markings or notations to the output MIDI or MusicXML.

**Python Code (Conceptual - Building on Step 5):**
6_gamaka_alankar_synth.py
$$
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import librosa
import music21
import numpy as np
import random

# GPU verification and memory management
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        logical_gpus = tf.config.list_logical_devices('GPU')
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")
    except RuntimeError as e:
        print(e)
else:
    print("No GPU detected, using CPU.")

def load_music_input(input_file):
    if input_file.lower().endswith(('.wav', '.mp3')):
        audio, sr = librosa.load(input_file)
        return audio, sr, "audio"
    elif input_file.lower().endswith(('.mid', '.midi', '.xml', '.musicxml')):
        score = music21.converter.parse(input_file)
        music_sequence = music21_to_sequence(score)
        return music_sequence, None, "symbolic"
    else:
        raise ValueError("Unsupported input file format")

def music21_to_sequence(score):
    sequence = []
    for element in score.recurse():
        if isinstance(element, music21.note.Note):
            sequence.append(f"note_{element.nameWithOctave}_{element.duration.quarterLength}")
        elif isinstance(element, music21.note.Rest):
            sequence.append(f"rest_{element.duration.quarterLength}")
        elif isinstance(element, music21.tempo.MetronomeMark):
            sequence.append(f"tempo_{element.number}")
        elif isinstance(element, music21.stream.Measure):
            sequence.append("measure_start")
    return sequence

def process_prompt_gamaka_alankar(prompt):
    prompt = prompt.lower()
    gamaka = "default"
    alankar = "default"
    if "andolan" in prompt:
        gamaka = "andolan"
    if "meend" in prompt:
        gamaka = "meend"
    if "sargam" in prompt:
        alankar = "sargam"
    if "alankar" in prompt and "simple" in prompt:
        alankar = "simple"

    return {"gamaka": gamaka, "alankar": alankar}

def transformer_audio_gamaka_alankar(audio, prompt_data):
    if prompt_data["gamaka"] == "andolan":
        pitch_shift = random.uniform(-0.5, 0.5)
        modified_audio = librosa.effects.pitch_shift(audio, sr=44100, n_steps=pitch_shift)
        return modified_audio
    elif prompt_data["gamaka"] == "meend":
        pitch_shift = random.uniform(-0.3, 0.3)
        modified_audio = librosa.effects.pitch_shift(audio, sr=44100, n_steps=pitch_shift)
        return modified_audio
    return audio

def transformer_symbolic_gamaka_alankar(music_sequence, prompt_data):
    modified_sequence = music_sequence.copy()
    if prompt_data["alankar"] == "sargam":
        sargam_pattern = ["note_C4_0.5", "note_D4_0.5", "note_E4_0.5", "note_F4_0.5", "note_G4_0.5", "note_A4_0.5", "note_B4_0.5", "note_C5_0.5"]
        modified_sequence.extend(sargam_pattern)
    elif prompt_data['alankar'] == 'simple':
        simple_pattern = ["note_C4_0.5", "note_D4_0.5", "note_E4_0.5"]
        modified_sequence.extend(simple_pattern)
    return modified_sequence

def latent_diffusion_gamaka_alankar(music_output):
    duration = 5
    sr = 44100
    t = np.linspace(0, duration, int(sr * duration), False)
    freq = 440
    audio = np.sin(2 * np.pi * freq * t)
    return audio

def music_sequence_to_midi(music_output, output_file):
    score = music21.stream.Stream()
    offset = 0
    for event in music_output:
        if event.startswith("note_"):
            parts = event.split("_")
            note_name = parts[1]
            duration = float(parts[2])
            note = music21.note.Note(note_name, quarterLength=duration)
            note.offset = offset
            score.append(note)
            offset += duration
        elif event.startswith("rest_"):
            duration = float(event.split("_")[1])
            rest = music21.note.Rest(quarterLength=duration)
            rest.offset = offset
            score.append(rest)
            offset += duration
        elif event.startswith("tempo_"):
            tempo = music21.tempo.MetronomeMark(number=float(event.split("_")[1]))
            score.append(tempo)
        elif event == "measure_start":
            pass

    mf = music21.midi.translate.streamToMidiFile(score)
    mf.open(output_file, 'wb')
    mf.write()
    mf.close()

def modify_music_gamaka_alankar(music_input, input_type, prompt_data):
    if input_type == "audio":
        modified_music = transformer_audio_gamaka_alankar(music_input, prompt_data)
        return modified_music, "audio"
    elif input_type == "symbolic":
        modified_music = transformer_symbolic_gamaka_alankar(music_input, prompt_data)
        return modified_music, "symbolic"
    else:
        raise ValueError("Invalid input type")

def synthesize_audio_gamaka_alankar(modified_music, modified_type):
    if modified_type == "audio":
        return modified_music
    elif modified_type == "symbolic":
        return latent_diffusion_gamaka_alankar(modified_music)
    else:
        raise ValueError("Invalid modified type")
# Example usage
try:
    input_file = "C:\\Users\\rsshi\\OneDrive\\Desktop\\GDSC'25\\kal.mp3"
    music_input, sr, input_type = load_music_input(input_file)
    prompt = "Add an andolan gamaka and a sargam alankar"
    prompt_data = process_prompt_gamaka_alankar(prompt)
    modified_music, modified_type = modify_music_gamaka_alankar(music_input, input_type, prompt_data)
    synthesized_audio = synthesize_audio_gamaka_alankar(modified_music, modified_type)
    output_music(synthesized_audio, "audio", "output_gamaka_alankar.wav", sr)
    print("Gamaka and Alankar Synthesis Implemented")
except Exception as e:
    print(f"An error occurred: {e}")
$$
OUTPUT:
again gpu u have everything downloaded cuda with cuDNN

___
Not Important Right Now

ADDITIONAL STEPS 
===**Step 7: Data Collection and Augmentation**=== - need to make ===sheet music using software=== - check output for step 7 for more details idk how to make it so i couldn't execute 

**Methodology:**

1. **Gather Datasets:**
    - Collect a comprehensive dataset of Indian Classical Music recordings and music sheets.
    - This dataset should include a wide range of ragas, talas, gamakas, and alankars.
    - You will need labeled data for note detection, raga/tala recognition, and gamaka/alankar generation.
2. **Data Augmentation:**
    - Use data augmentation techniques to increase the size and diversity of your dataset.
    - This could involve:
        - Pitch shifting.
        - Time stretching.
        - Adding noise.
        - Mixing audio clips.
        - Generating variations of music sheets.

**Python Code (Conceptual - Using `librosa` and `music21`):** 
7_data_coll_aug.py
$$
import librosa  
import music21  
import numpy as np  
import random  
  
def augment_audio(audio, sr, pitch_shift_range=2, time_stretch_range=0.2, noise_level=0.01):  
    """Augments audio data."""  
    # Pitch shift  
    pitch_shift = random.uniform(-pitch_shift_range, pitch_shift_range)  
    augmented_audio = librosa.effects.pitch_shift(audio, sr=sr, n_steps=pitch_shift)  
  
    # Time stretch  
    time_stretch = random.uniform(1 - time_stretch_range, 1 + time_stretch_range)  
    augmented_audio = librosa.effects.time_stretch(augmented_audio, rate=time_stretch)  
  
    # Add noise  
    noise = np.random.normal(0, noise_level, len(augmented_audio))  
    augmented_audio += noise  
  
    return augmented_audio  
  
def augment_music_sheet(score, pitch_shift_range=2, time_stretch_range=0.2):  
    """Augments music sheet data."""  
    augmented_score = score.clone()  # Create a copy  
  
    # Pitch Augmentation    interval = music21.interval.ChromaticInterval(random.randint(-pitch_shift_range, pitch_shift_range))  
    for note in augmented_score.recurse().notes:  
        note.transpose(interval, inPlace=True)  
  
    # Rhythm Augmentation  
    for note in augmented_score.recurse().notes:  
        if random.random() < 0.2:  # 20% chance to change duration  
            durations = [0.25, 0.5, 1.0, 2.0]  # Example durations  
            note.duration.quarterLength = random.choice(durations)  
  
    # Add grace notes  
    for note in augmented_score.recurse().notes:  
        if random.random() < 0.1:  # 10% chance to add grace note  
            grace = music21.note.GraceNote("C4", quarterLength=0.1)  
            augmented_score.insert(note.offset, grace)  
  
    # Articulation changes  
    for note in augmented_score.recurse().notes:  
        if random.random() < 0.15:  
            if random.random() < 0.5:  
                note.articulations.append(music21.articulations.Staccato())  
            else:  
                note.articulations.append(music21.articulations.Tenuto())  
  
    # Dynamic changes  
    for element in augmented_score.recurse().getElementsByClass('Dynamic'):  
        if random.random() < 0.2:  
            dynamics = ['ff', 'f', 'mf', 'mp', 'p', 'pp']  
            element.value = random.choice(dynamics)  
  
    return augmented_score  
  
# --- Example Usage ---  
  
audio, sr = librosa.load("input.wav")  # REPLACE WITH YOUR AUDIO FILE  
augmented_audio = augment_audio(audio, sr)  
librosa.output.write_wav("augmented_audio.wav", augmented_audio, sr)  
  
score = music21.converter.parse("input.xml")  # REPLACE WITH YOUR MUSICXML FILE  
augmented_score = augment_music_sheet(score)  
augmented_score.write("musicxml", "augmented_score.xml")  
  
print("Data Augmentation Implemented")
$$
OUTPUT:
didn't execute have to Download: [https://musescore.org/](https://musescore.org/) to create sheet music and replace the input.xml file with the MusicXML file created using the software...

Software downloading still...ok i dont understand how to make the sheet music so u download the software museScore create a sheet and replace the input.wav file and input.xml file 


**Step 8: Evaluation**

**Methodology:**

1. **Define Metrics:**
    - Define appropriate metrics to evaluate the performance of your models.
    - For note detection: accuracy, precision, recall, F1-score.
    - For raga/tala recognition: accuracy, precision, recall, F1-score.
    - For audio synthesis: perceptual evaluation metrics (e.g., MOS, PESQ).
    - For gamaka/alankar generation: subjective evaluation by experts.
2. **Implement Evaluation:**
    - Implement evaluation functions to calculate the defined metrics.
    - Use a separate test dataset to evaluate the models.
3. **Analyze Results:**
    - Analyze the evaluation results to identify areas for improvement.
    - Fine-tune the models and hyperparameters based on the evaluation results.

**Step 9: User Interface (UI)**

**Methodology:**

1. **Design UI:**
    - Design a user-friendly interface for your system.
    - Consider using a GUI library like Tkinter, PyQt, or web-based frameworks like Flask or Django.
2. **Implement UI:**
    - Implement the UI based on your design.
    - Integrate the UI with your models and audio processing functions.
3. **Test and Iterate:**
    - Test the UI with users and iterate on the design based on feedback.