**I. Core ML Concepts & Models:**

- **General Machine Learning:**
    - **TensorFlow Documentation:**  (TENSORFLOW !!!!!!!) 
        - Website: [https://www.tensorflow.org/](https://www.tensorflow.org/)
    - **PyTorch Documentation:**
        - Website: [https://pytorch.org/](https://pytorch.org/)
- **Convolutional Neural Networks (CNNs):**
    - **"Deep convolutional networks and data augmentation for environmental sound classification" (Piczak, 2015):**
        - Research Paper: [https://www.researchgate.net/publication/283307567_Environmental_sound_classification_using_Convolutional_Neural_Networks](https://www.google.com/search?q=https://www.researchgate.net/publication/283307567_Environmental_sound_classification_using_Convolutional_Neural_Networks)
    - **"Environmental sound classification with convolutional neural networks" (Salamon & Bello, 2017):**
        - Research Paper: [https://www.researchgate.net/publication/313886751_Deep_Convolutional_Neural_Networks_and_Data_Augmentation_for_Environmental_Sound_Classification](https://www.google.com/search?q=https://www.researchgate.net/publication/313886751_Deep_Convolutional_Neural_Networks_and_Data_Augmentation_for_Environmental_Sound_Classification)
- **Recurrent Neural Networks (RNNs) and LSTMs:**
    - **"Generating long sequences with recurrent neural networks" (Sutskever et al., 2011):**
        - Research Paper: [https://proceedings.neurips.cc/paper_files/paper/2011/file/3644a684f98ea8fe223c713b77189a77-Paper.pdf](https://proceedings.neurips.cc/paper_files/paper/2011/file/3644a684f98ea8fe223c713b77189a77-Paper.pdf)
    - **"Long short-term memory" (Hochreiter & Schmidhuber, 1997):**
        - Research Paper: [https://www.researchgate.net/publication/13853244_Long_Short-Term_Memory](https://www.researchgate.net/publication/13853244_Long_Short-Term_Memory)
- **Transformers:**
    - **"Attention is all you need" (Vaswani et al., 2017):**
        - Research Paper: [https://arxiv.org/abs/1706.03762](https://arxiv.org/abs/1706.03762)
    - **"Music transformer: Generating music with long-term structure" (Huang et al., 2018):**
        - Research Paper: [https://arxiv.org/abs/1809.04281](https://arxiv.org/abs/1809.04281)
- **Variational Autoencoders (VAEs) and GANs:**
    - **"Auto-encoding variational bayes" (Kingma & Welling, 2013):**
        - Research Paper: [https://arxiv.org/abs/1312.6114](https://arxiv.org/abs/1312.6114)
    - **"Generative adversarial nets" (Goodfellow et al., 2014):**
        - Research Paper: [https://arxiv.org/abs/1406.2661](https://arxiv.org/abs/1406.2661)
- **Latent Diffusion Models:**
    - **"Denoising diffusion probabilistic models" (Ho et al., 2020):**
        - Research paper: [https://arxiv.org/abs/2006.11239](https://arxiv.org/abs/2006.11239)
    - **"High fidelity audio generation with latent diffusion models" (Zeghidour et al., 2023):**
        - Research paper: [https://arxiv.org/abs/2301.12502](https://arxiv.org/abs/2301.12502)

**II. Audio Processing & Music Information Retrieval:**

- **STFT (Short-Time Fourier Transform):**
    - Explanation: [https://en.wikipedia.org/wiki/Short-time_Fourier_transform](https://en.wikipedia.org/wiki/Short-time_Fourier_transform)
- **Constant-Q Transform (CQT):**
    - Explanation: [https://en.wikipedia.org/wiki/Constant-Q_transform](https://en.wikipedia.org/wiki/Constant-Q_transform)
- **MFCCs (Mel-Frequency Cepstral Coefficients):**
    - Explanation: [https://en.wikipedia.org/wiki/Mel-frequency_cepstrum](https://en.wikipedia.org/wiki/Mel-frequency_cepstrum)
- **MIDI (Musical Instrument Digital Interface):**
    - Explanation: [https://en.wikipedia.org/wiki/MIDI](https://en.wikipedia.org/wiki/MIDI)
- **MusicXML:**
    - Website: [https://www.musicxml.com/](https://www.musicxml.com/)
- **Librosa (Python Audio Analysis Library):**
    - Documentation: [https://librosa.org/doc/latest/index.html](https://librosa.org/doc/latest/index.html)

**III. Indian Classical Music & Related Research:**

- **Computational Ethnomusicology:**
    - Search on Google scholar for "computational ethnomusicology" to find many papers.
- **Raga Analysis:**
    - Search on Google scholar for "raga classification", or "raga recognition"
- **Tala Analysis:**
    - Search on Google scholar for "tala recognition", or "tala analysis"
- **Microtonal Analysis:**
    - Search on Google scholar for "microtonal music analysis", or "shruti analysis"

**IV. General Resources:**

- **arXiv (Open-Access Research Papers):**
    - Website: [https://arxiv.org/](https://arxiv.org/)
- **Google Scholar:**
    - Website: [https://scholar.google.com/](https://scholar.google.com/)
- **ResearchGate:**
    - Website: [https://www.researchgate.net/](https://www.google.com/url?sa=E&source=gmail&q=https://www.researchgate.net/)

**Important Notes:**

- Many research papers are available through academic databases (like ==IEEE Xplore==, ACM Digital Library), which may require institutional access.
- When searching ===Google Scholar===, use specific keywords related to your project (e.g., "deep learning Indian classical music," "raga classification CNN," "latent diffusion audio synthesis").